USE pubs

-- 1. Pubs - What authors are in California --

SELECT au_fname, au_lname 
FROM [dbo].[authors]
WHERE dbo.authors.state = 'CA' ;

--2.   Pubs - List the titles and author names --
SELECT a.title, c.au_fname, c.au_lname
FROM [dbo].[titles] a 
INNER JOIN [dbo].[titleauthor] b ON a.title_id = b.title_id
INNER JOIN [dbo].[authors] c ON b.au_id = c.au_id;

--3.   Pubs - List all employees and their jobs --
SELECT a.emp_id, a.fname, a.lname, b.job_desc
FROM [dbo].[employee] a 
JOIN [dbo].[jobs] b ON A.job_id = b.job_id;

-- 4.   Pubs - List the titles by total sales price --
SELECT title, price
FROM [dbo].[titles]
ORDER BY price DESC;

--5.   Pubs - Find the total sales by store for stores in California--
SELECT a.stor_id, b.stor_name, SUM(a.qty) as Total_Sales
FROM [dbo].[sales] a 
JOIN [dbo].[stores] b ON a.stor_id = b.stor_id
WHERE B.state = 'CA'
GROUP BY a.stor_id, b.stor_name;

-- 6.   Pubs - List the store name, title title name and quantity for all stores that have net 30 payterms --
SELECT b.stor_name, a.title_id, c.title, a.qty
FROM [dbo].[sales] a 
JOIN [dbo].[stores] b ON a.stor_id = b.stor_id 
JOIN [dbo].[titles] c ON a.title_id = c.title_id
WHERE a.payterms = 'Net 30';

--7.   Pubs - Find the titles that do not have any sales show the name of the title --
SELECT title 
FROM [dbo].[titles]
WHERE ytd_sales IS NULL;

--8.   Pubs - Do previous question another way --
SELECT a.title_id, a.title
FROM [dbo].[titles] a
WHERE a.title_id NOT IN (SELECT title_id FROM [dbo].[sales]);

-- 9.   AdventureWorks - List all the employees show name and department --
use AdventureWorks2014 
SELECT a.[FirstName], a.[MiddleName], a.[LastName], c.name
FROM [Person].[Person] a
JOIN [HumanResources].[EmployeeDepartmentHistory] B ON A.BusinessEntityID = B.BusinessEntityID
JOIN [HumanResources].[Department] c ON B.DepartmentID =C.DepartmentID;

--10.   AdventureWorks - Show the employees and their current and prior departments --
SELECT c.BusinessEntityID,
	   c.FirstName, 
	   c.lastname,
	   (CASE WHEN A.enddate IS NULL THEN b.name END ) AS Current_Department,
       (CASE WHEN a.enddate IS NOT NULL THEN b.name, END) AS Prior_Department
FROM [HumanResources].[EmployeeDepartmentHistory] a 
JOIN [HumanResources].[Department] b ON a.DepartmentID = b.DepartmentID
JOIN [Person].[Person] c ON a.BusinessEntityID = c.BusinessEntityID;

--11.   AdventureWorks - Break apart the employee login id so that you have the domain (before the /) in one column and the login id (after the /) in two columns--
USE AdventureWorks2014

SELECT CASE WHEN CHARINDEX('\',LoginID) > 0
			THEN SUBSTRING(LoginID,1,CHARINDEX('\',LoginID)-1)
		ELSE LoginID END Domain_Name,
		CASE WHEN CHARINDEX('\',LoginID) > 0
			THEN SUBSTRING(LoginID,CHARINDEX('\',LoginID)+1,LEN(LoginID))
		ELSE Null END First_Name
FROM [HumanResources].[Employee];

-- 12. AdventureWorks - Build a new column in a copy of the employee table that is the employee email address in the form login_id@domain.com, populate the column --

--create the table--
SELECT * INTO [dbo].[Copy_Employee] FROM [HumanResources].[Employee];

--Check the table--
SELECT * FROM [dbo].[Copy_Employee];

--Add a column email address into the table--
ALTER TABLE [dbo].[Employee_Copy]
ADD Email_Address nvarchar(100) ;

--update the new column with the required values--
update [dbo].[Employee_Copy]
set Email_Address = concat(SUBSTRING(loginid, 17, CHARINDEX('\',loginid,0)) ,'@',
					  SUBSTRING(loginid, 0, CHARINDEX('\',loginid,0)) , '.com')

--check the resulting table--
SELECT * FROM [dbo].[Employee_Copy];


--13. AdventureWorks - Calculate the age of an employee in years - Does it work if the birthday hasn't happened yet if not fix it 
SELECT BusinessEntityID, LoginID, BirthDate,
CASE WHEN DATEADD(YY,DATEDIFF(yy,BirthDate,GETDATE()),BirthDate)<GETDATE() THEN DATEDIFF(yy,BirthDate,GETDATE())
ELSE DATEDIFF(yy,BirthDate,GETDATE())-1 END AS AGE
FROM HumanResources.Employee
ORDER BY BirthDate;















		



